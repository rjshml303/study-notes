# Study Notes — Starter Template

Ye starter template MkDocs (Material) ka simple setup hai jo GitHub Actions se automatic deploy karega
to `gh-pages` branch. Ye free aur easily editable hai — aap GitHub web UI se bhi direct files edit kar sakte ho.

## Files included
- `docs/` : Markdown pages (index.md, python.md, telecom.md)
- `mkdocs.yml` : MkDocs configuration (Material theme + awesome-pages plugin)
- `.github/workflows/deploy.yml` : GitHub Actions workflow to build & deploy

## Quick steps (short)
1. Download and unzip the starter (ya clone the repo after you push it to GitHub).
2. Create a new GitHub repo and push these files to the `main` branch.
3. GitHub Actions will build the site and publish to `gh-pages`.
4. Edit Markdown files directly on GitHub to update content.


# Python Notes

- Variables, Data types
- Lists, Tuples, Sets
- Loops (for, while)
- Functions
- Numpy introduction (arrays, max/min/mean)

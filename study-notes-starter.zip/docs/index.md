# Swagat hai — My Study Notes

Ye mera personal study-notes repository hai. Yahan aap apne chapters (Python, Telecom, PMP, etc.)
Markdown files ke roop mein add kar sakte ho. Website automatic generate ho jayegi jab aap
changes push karoge.

## Shuru karne ke liye
- `docs/` ke andar naye `.md` files banao (jaise `python.md`, `telecom.md`).
- GitHub par push karte hi site update ho jayegi (GitHub Actions use karega).

---

**Topics**
- Python
- Telecom


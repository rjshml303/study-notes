# Telecom Notes

- Basic Concepts
- 4G / 5G overview
- Network rollout essentials
